import 'package:google_mlkit_translation/google_mlkit_translation.dart';

/// Тарҷумаи офлайни матн бо истифода аз Google ML Kit.
/// Барои ҳар ҷуфти забон, модели хурд (тахминан 30 МБ) бояд як
/// маротиба боргирӣ шавад (ҳангоми интернет доштан), баъд аз он
/// тарҷума пурра офлайн кор мекунад.
///
/// ДИҚҚАТ: ML Kit забони тоҷикиро бевосита дастгирӣ намекунад.
/// Барои корбарони тоҷикизабон, тавсия мешавад аз русӣ ҳамчун
/// забони мобайнӣ истифода баред (тоҷикӣ ва русӣ бисёр вожаи
/// умумӣ доранд ва аксари корбарон русиро мефаҳманд), ё маводи
/// матнро бо алифбои лотинӣ/форсӣ санҷед вобаста ба ниёз.
class TranslateService {
  OnDeviceTranslator? _translator;
  TranslateLanguage? _sourceLang;
  TranslateLanguage? _targetLang;

  final OnDeviceTranslatorModelManager _modelManager =
      OnDeviceTranslatorModelManager();

  /// Боргирии модели забон ба хотираи дастгоҳ (як маротиба, бо интернет)
  Future<void> downloadLanguageModel(TranslateLanguage language) async {
    await _modelManager.downloadModel(language.bcpCode);
  }

  Future<bool> isModelDownloaded(TranslateLanguage language) {
    return _modelManager.isModelDownloaded(language.bcpCode);
  }

  Future<void> deleteLanguageModel(TranslateLanguage language) async {
    await _modelManager.deleteModel(language.bcpCode);
  }

  void _ensureTranslator(TranslateLanguage source, TranslateLanguage target) {
    if (_sourceLang != source || _targetLang != target) {
      _translator?.close();
      _translator = OnDeviceTranslator(
        sourceLanguage: source,
        targetLanguage: target,
      );
      _sourceLang = source;
      _targetLang = target;
    }
  }

  /// Тарҷумаи матн аз як забон ба забони дигар (пурра офлайн,
  /// баъд аз он ки моделҳо боргирӣ шудаанд).
  Future<String> translate({
    required String text,
    required TranslateLanguage from,
    required TranslateLanguage to,
  }) async {
    _ensureTranslator(from, to);
    return _translator!.translateText(text);
  }

  void dispose() {
    _translator?.close();
  }
}
