import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:flutter_tts/flutter_tts.dart';

/// Ин класс ду вазифаро иҷро мекунад:
/// 1) Гап -> матн (STT) — овози корбарро мешунавад ва ба матн табдил медиҳад
/// 2) Матн -> гап (TTS) — ҷавоби AI-ро бо овоз мехонад
///
/// Ҳарду низом дар дастгоҳ (офлайн) кор мекунанд, ба шарте ки
/// забони лозима дар танзимоти телефон насб шуда бошад
/// (Android: Settings -> System -> Languages -> дидан барои
/// овозҳои офлайни насбшуда).
class VoiceService {
  final stt.SpeechToText _speech = stt.SpeechToText();
  final FlutterTts _tts = FlutterTts();

  bool _speechReady = false;

  /// Забони шинохт ва гуфтор. Тағйир диҳед агар корбар забони дигар хоҳад.
  /// Мисолҳо: 'tg-TJ' (тоҷикӣ — агар дастгоҳ дастгирӣ кунад),
  /// 'ru-RU' (русӣ), 'en-US' (англисӣ).
  String localeId = 'ru-RU';

  Future<bool> init() async {
    _speechReady = await _speech.initialize(
      onError: (e) => print('STT error: $e'),
      onStatus: (s) => print('STT status: $s'),
    );
    await _tts.setLanguage(localeId);
    await _tts.setSpeechRate(0.48);
    return _speechReady;
  }

  bool get isListening => _speech.isListening;

  /// Гӯш кардани овози корбар. `onResult` бо матни то ҳол
  /// шинохташуда борҳо даъват мешавад (натиҷаи зинда).
  Future<void> startListening({
    required void Function(String recognizedText, bool isFinal) onResult,
  }) async {
    if (!_speechReady) {
      _speechReady = await _speech.initialize();
    }
    if (!_speechReady) return;

    await _speech.listen(
      localeId: localeId,
      onResult: (result) {
        onResult(result.recognizedWords, result.finalResult);
      },
    );
  }

  Future<void> stopListening() async {
    await _speech.stop();
  }

  /// Хондани матн бо овоз
  Future<void> speak(String text) async {
    if (text.trim().isEmpty) return;
    await _tts.stop();
    await _tts.speak(text);
  }

  Future<void> stopSpeaking() async {
    await _tts.stop();
  }
}
