import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

/// Ин класс паёмҳои чатро дар хотираи дастгоҳ нигоҳ медорад, то
/// баъд аз баста шудани барнома ва кушодани дубора, суҳбат нест нашавад.
class ChatStorage {
  static const String _key = 'chat_history_v1';

  /// Нигоҳ доштани рӯйхати паёмҳо (ҳар паём: {role, content})
  Future<void> saveMessages(List<Map<String, String>> messages) async {
    final prefs = await SharedPreferences.getInstance();
    final jsonString = jsonEncode(messages);
    await prefs.setString(_key, jsonString);
  }

  /// Хондани паёмҳои нигоҳдошташуда (агар набошанд, рӯйхати холӣ)
  Future<List<Map<String, String>>> loadMessages() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonString = prefs.getString(_key);
    if (jsonString == null || jsonString.isEmpty) return [];

    final decoded = jsonDecode(jsonString) as List<dynamic>;
    return decoded
        .map((item) => Map<String, String>.from(item as Map))
        .toList();
  }

  /// Тоза кардани пурраи таърихи чат (масалан бо тугмаи "Чати нав")
  Future<void> clearMessages() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }
}
