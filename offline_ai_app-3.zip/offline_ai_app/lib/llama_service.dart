import 'dart:async';
import 'dart:io';
import 'package:fllama/fllama.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path_provider/path_provider.dart';

/// Ин класс модели офлайнро (GGUF) идора мекунад:
/// аз assets ба хотираи дастгоҳ нусха мебардорад ва
/// пайдарпаии чат-ро ба мотори llama.cpp мефиристад.
class LlamaService {
  static const String modelAssetPath = 'assets/models/model.gguf';
  static const String modelFileName = 'model.gguf';

  /// Дастури системавӣ — ба AI мегӯяд бо забони тоҷикӣ ҷавоб диҳад
  /// ва созандаи барномаро мешиносад.
  static const String systemPrompt =
      'Ту як ёрдамчии ҳушманди муфид ҳастӣ, ки Шафиев Зиёвуддин '
      'туро сохтааст. Агар касе пурсад «Туро кӣ сохтааст?» ё ба ин '
      'монанд, бигӯ ки созандаи ту Шафиев Зиёвуддин аст. Ҳамеша бо '
      'забони тоҷикӣ (алифбои кириллӣ) ҷавоб деҳ, ба истиснои ҳолате '
      'ки корбар бо забони дигар савол диҳад — дар он сурат бо ҳамон '
      'забон ҷавоб деҳ. Ҷавобҳоятро равшан ва фаҳмо нависед.';

  String? _localModelPath;

  /// Модел бояд танҳо як маротиба (ҳангоми аввалин иҷро) ба хотираи
  /// дастгоҳ нусха бардошта шавад — баъд аз он бидуни интернет кор мекунад.
  Future<String> ensureModelReady({
    void Function(double progress)? onProgress,
  }) async {
    if (_localModelPath != null) return _localModelPath!;

    final dir = await getApplicationSupportDirectory();
    final localFile = File('${dir.path}/$modelFileName');

    if (await localFile.exists()) {
      _localModelPath = localFile.path;
      return _localModelPath!;
    }

    // Нусхабардорӣ аз assets ба хотираи дастгоҳ
    final byteData = await rootBundle.load(modelAssetPath);
    final buffer = byteData.buffer;
    await localFile.writeAsBytes(
      buffer.asUint8List(byteData.offsetInBytes, byteData.lengthInBytes),
    );

    _localModelPath = localFile.path;
    return _localModelPath!;
  }

  /// Фиристодани паём ба AI ва гирифтани ҷавоб ба тарзи stream
  /// (ҳарф ба ҳарф, монанди чат-ботҳои воқеӣ).
  Stream<String> chat({
    required String userMessage,
    required List<Map<String, String>> history, // [{role, content}, ...]
  }) async* {
    final modelPath = await ensureModelReady();

    final messages = [
      Message(Role.system, systemPrompt),
      ...history.map((m) => Message(
            _roleFromString(m['role']!),
            m['content']!,
          )),
      Message(Role.user, userMessage),
    ];

    final request = OpenAiRequest(
      maxTokens: 512,
      messages: messages,
      numGpuLayers: 99, // истифодаи GPU/NPU-и дастгоҳ агар дастрас бошад
      modelPath: modelPath,
      temperature: 0.7,
      topP: 0.9,
    );

    final controller = StreamController<String>();
    String fullResponse = '';

    fllamaChat(request, (response, openAiResponseJsonString, done) {
      // response - матни то ҳол ҷамъшуда
      final newPart = response.substring(fullResponse.length);
      fullResponse = response;
      if (newPart.isNotEmpty) controller.add(newPart);
      if (done) controller.close();
    });

    yield* controller.stream;
  }

  Role _roleFromString(String role) {
    switch (role) {
      case 'user':
        return Role.user;
      case 'assistant':
        return Role.assistant;
      case 'system':
        return Role.system;
      default:
        return Role.user;
    }
  }

  /// Тарҷумаи матн ба забони дилхоҳ (аз ҷумла тоҷикӣ) бо истифода аз
  /// худи модели маҳаллӣ — азбаски китобхонаҳои тарҷумаи офлайн
  /// (ба монанди ML Kit) забони тоҷикиро дастгирӣ намекунанд.
  /// Натиҷа якбора (на stream) бармегардад.
  Future<String> translateText({
    required String text,
    required String targetLanguageName, // масалан: "тоҷикӣ", "русӣ", "англисӣ"
  }) async {
    final modelPath = await ensureModelReady();

    final prompt = 'Матни зеринро танҳо ба забони $targetLanguageName '
        'тарҷума кун. Ҳеҷ изоҳ, шарҳ ё матни иловагӣ нанавис — фақат '
        'тарҷумаи холисро баргардон.\n\nМатн:\n"$text"';

    final request = OpenAiRequest(
      maxTokens: 512,
      messages: [
        Message(Role.system,
            'Ту як мутарҷими дақиқ ҳастӣ. Танҳо тарҷумаро бидеҳ, чизи дигар нанавис.'),
        Message(Role.user, prompt),
      ],
      numGpuLayers: 99,
      modelPath: modelPath,
      temperature: 0.3, // барои дурустии бештар дар тарҷума
      topP: 0.9,
    );

    final completer = Completer<String>();
    fllamaChat(request, (response, openAiResponseJsonString, done) {
      if (done) completer.complete(response.trim());
    });

    return completer.future;
  }
}
